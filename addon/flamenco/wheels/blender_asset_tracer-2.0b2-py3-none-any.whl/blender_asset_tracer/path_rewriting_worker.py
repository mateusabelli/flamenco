# SPDX-FileCopyrightText: 2026 Blender Authors
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Python script for path rewriting, run in a background Blender process.

See `blender_asset_tracer/path_rewriting_process.py` for the code that runs in the main
process, and manages this background process.
"""

import functools
import logging
import os
import queue
import sys
import threading
from multiprocessing.connection import Client, Connection
from pathlib import Path

_logger = logging.getLogger(__name__)

# Ensure BAT can be imported, even when it's not installed as package.
_bat_parent_dir = Path(__file__).resolve().parent.parent
if str(_bat_parent_dir) not in sys.path:
    sys.path.append(str(_bat_parent_dir))

from blender_asset_tracer import path_rewriting
from blender_asset_tracer.path_rewriting_models import (
    PipeMessage,
    PipeMsgType,
    RewriteRequest,
)

type MessageQueue = queue.Queue[PipeMessage]
type RewriteQueue = queue.Queue[RewriteRequest]


def main() -> None:
    logging.basicConfig(
        format=f"%(asctime)-15s {Path(__file__).stem:>22} %(levelname)8s %(name)s %(message)s",
        level=logging.INFO,
    )
    log = _logger.getChild("background_rewriter")
    log.info("Rewriter background process starting")

    connection = _connect_to_main_process()

    # Queues for incoming & outgoing messages.
    rx_queue: MessageQueue = queue.Queue()
    tx_queue: MessageQueue = queue.Queue()

    do_shutdown = threading.Event()

    rx_thread = threading.Thread(
        target=functools.partial(
            rx_thread_func,
            connection,
            rx_queue,
            do_shutdown,
            log,
        )
    )
    tx_thread = threading.Thread(
        target=functools.partial(
            tx_thread_func,
            connection,
            tx_queue,
            do_shutdown,
            log,
        )
    )
    rx_thread.start()
    tx_thread.start()

    try:
        main_loop(rx_queue, tx_queue, do_shutdown, log)
    except KeyboardInterrupt:
        log.warning("Keyboard interrupt received, shutting down the rewriter process")
        do_shutdown.set()
    except Exception:
        log.exception("Rewriter main loop had unexpected exception, shutting down")
        do_shutdown.set()

    try:
        rx_thread.join(timeout=1.0)
    except RuntimeError:
        log.exception("joining RX thread")

    try:
        tx_thread.join(timeout=1.0)
    except RuntimeError:
        log.exception("joining TX thread")

    log.debug("download process shutting down")


def main_loop(
    rx_queue: MessageQueue,
    tx_queue: MessageQueue,
    do_shutdown: threading.Event,
    log: logging.Logger,
) -> None:

    # Queue of files to rewrite.
    rewrite_queue: RewriteQueue = queue.Queue()

    while check_incoming_messages(rx_queue, rewrite_queue, do_shutdown):
        # Pop an item off the front of the queue.
        try:
            # If the queue is empty, the timeout just slows us down a bit. There
            # is no other thread that puts items into the queue, that's done in
            # check_incoming_messages().
            rewrite_request = rewrite_queue.get(timeout=0.1)
        except queue.Empty:
            continue

        assert rewrite_request is not None
        assert isinstance(rewrite_request, RewriteRequest), (
            f"got {type(rewrite_request)}: {rewrite_request!r}"
        )

        tx_queue.put(
            PipeMessage(
                msgtype=PipeMsgType.REPORT_START,
                payload=rewrite_request,
            )
        )

        try:
            _logger.info(
                "Path-rewriting file:\n"
                "  source   : %s\n"
                "  in pack  : %s\n"
                "  pack root: %s\n"
                "  cache to : %s",
                rewrite_request.blendfile,
                rewrite_request.relpath_in_root,
                rewrite_request.pack_source_root,
                rewrite_request.save_to,
            )

            # Do the actual path rewriting.
            path_rewriting.rewrite_file(rewrite_request)
        except Exception as ex:
            # Unexpected errors should really be logged here, as they may
            # indicate bugs (typos, dependencies not found, etc).
            log.exception(
                "unexpected error rewriting paths: %s",
                ex,
            )
            # Including the exception type ensures that the string is not empty,
            # even when str(ex) were to return an empty string. This happens,
            # for example, when raising a NotImplementedError() without explicit
            # message.
            tx_queue.put(
                PipeMessage(
                    msgtype=PipeMsgType.REPORT_ERROR,
                    payload=(rewrite_request, f"{type(ex).__name__}: {ex!s}"),
                )
            )
            # Keep running the queue, because this might have been an issue with
            # a specific file, and not impact anything else.
            continue

        tx_queue.put(
            PipeMessage(
                msgtype=PipeMsgType.REPORT_DONE,
                payload=rewrite_request,
            )
        )


def check_incoming_messages(
    rx_queue: MessageQueue,
    rewrite_queue: RewriteQueue,
    do_shutdown: threading.Event,
) -> bool:
    """Handle received messages, and return whether we can keep running.

    This rapidly handles all incoming messages. Anything the main loop
    should do will be pushed onto the rewrite_queue.

    If any SHUTDOWN message is received, the `do_shutdown` event is set
    immediately, and `False` is returned.
    """

    while not do_shutdown.is_set():
        try:
            received_msg: PipeMessage = rx_queue.get(block=False)
        except queue.Empty:
            # Not receiving anything is fine.
            break

        # Deal with those message types that can be sent to us.
        match received_msg.msgtype:
            case PipeMsgType.SHUTDOWN:
                do_shutdown.set()
            case PipeMsgType.QUEUE_REWRITE:
                assert isinstance(received_msg.payload, RewriteRequest)
                rewrite_queue.put(received_msg.payload)

    return not do_shutdown.is_set()


def rx_thread_func(
    connection: Connection,
    rx_queue: MessageQueue,
    do_shutdown: threading.Event,
    log: logging.Logger,
) -> None:
    """Process incoming messages."""

    while not do_shutdown.is_set():
        # Always keep receiving messages while they're coming in,
        # to prevent the remote end hanging on their send() call.
        # Only once that's done should we check the do_shutdown event.
        while connection.poll():
            try:
                received = connection.recv()
            except (EOFError, OSError):
                # The Python documentation mentions EOFError, but in
                # practice I (Sybren) have also seen a ConnectionResetError
                # being raised when Blender shuts down uncleanly. The
                # implementation of .send() shows that it can also raise an
                # OSError, which is the superclass of ConnectionResetError
                # as well, so that's why that's caught here.
                log.warning(
                    "Blender is no longer running, shutting down the rewriter process"
                )
                do_shutdown.set()
                return

            received_msg = PipeMessage.unserialize(received)
            log.debug("received message: %s", received_msg)
            rx_queue.put(received_msg)


def tx_thread_func(
    connection: Connection,
    tx_queue: MessageQueue,
    do_shutdown: threading.Event,
    log: logging.Logger,
) -> None:
    """Send queued reports back to the main process."""
    while not do_shutdown.is_set():
        try:
            queued_msg = tx_queue.get(timeout=0.1)
        except queue.Empty:
            # Not having anything to transmit is fine.
            continue

        queued_dict = queued_msg.serialize()
        log.debug("TX: sending message %s", queued_dict)
        try:
            connection.send(queued_dict)
        except OSError:
            # The Python documentation doesn't mention any exceptions for
            # the .send() function. In practice, I (Sybren) have seen a
            # BrokenPipeError being raised. The implementation of .send()
            # shows that it can also raise an OSError, which is the
            # superclass of BrokenPipeError as well.
            log.warning(
                "Blender is no longer running, shutting down the rewriter process"
            )
            do_shutdown.set()
            return


def _connect_to_main_process() -> Connection:
    listener_host: str = os.environ["LISTENER_HOST"]
    listener_port: int = int(os.environ["LISTENER_PORT"])
    listener_address = (listener_host, listener_port)

    listener_secret = os.environ["LISTENER_SECRET"]

    client = Client(listener_address, authkey=listener_secret.encode())
    return client


if __name__ == "__main__":
    main()
